// //import Navbar from './Components/Navbar/Navbar';
// import React from 'react'
// // import Slider from './Components/home/Slider/Slider'
// // import Sliderdata from './Components/home/Slider/Slider' 
// import Flash from './Components/Flash/Flash';
// import Flashs from './Components/Flash/Flash';
// import MainRoutes from './Routes/MainRoutes';
// import Megha from "./Components/Meghamenu/Megha";
import Footer from "./Components/Footer/Footer";
import React from "react";
import MainRoutes from "./Routes/MainRoutes";

function App() {

  return ( < MainRoutes / > );
}


export default App