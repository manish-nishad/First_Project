import React from 'react'

export const FlashEvents = () => {
  return (
    <div>Flash Events</div>
  )
}
export default FlashEvents;