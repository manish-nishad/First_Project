import React from "react";
import Momgift, { Motherfaq, Therealdeal } from "./Momgift";
import Shopyourway from "./Shopyourway";

const Gift = () => {
  return (
    <>
      <Momgift />
      <Therealdeal />
      <Motherfaq />
      <Shopyourway />
    </>
     
  
  );
};

export default Gift;