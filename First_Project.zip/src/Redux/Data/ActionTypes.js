export const SIGNIN_1 = "SIGNIN_1";
export const DETAILS = "DETAILS";
export const SIGN_OUT = "SIGN_OUT";

export const LOG_IN = "LOG_IN";
export const DESCRIPTION_DATA ="DESCRIPTION_DATA";

export const SORTED_DATA = "SORTED_DATA"

export const MAINSTATE_TRUE = "MAINSTATE_TRUE";

export const MAINSTATE_FALSE = "MAINSTATE_FALSE"
export const REMOVE_CART_ITEM = "REMOVE_CART_ITEM";
export const ADD_TO_BAG = "ADD_TO_BAG";
export const FORM_DATA = "FORM_DATA";




